<?php

namespace App\Repository;

use App\Entity\NiPersonnephysique;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @method NiPersonnephysique|null find($id, $lockMode = null, $lockVersion = null)
 * @method NiPersonnephysique|null findOneBy(array $criteria, array $orderBy = null)
 * @method NiPersonnephysique[]    findAll()
 * @method NiPersonnephysique[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class NiPersonnephysiqueRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, NiPersonnephysique::class);
    }

    // /**
    //  * @return NiPersonnephysique[] Returns an array of NiPersonnephysique objects
    //  */
    /*
    public function findByExampleField($value)
    {
        return $this->createQueryBuilder('n')
            ->andWhere('n.exampleField = :val')
            ->setParameter('val', $value)
            ->orderBy('n.id', 'ASC')
            ->setMaxResults(10)
            ->getQuery()
            ->getResult()
        ;
    }
    */

    /*
    public function findOneBySomeField($value): ?NiPersonnephysique
    {
        return $this->createQueryBuilder('n')
            ->andWhere('n.exampleField = :val')
            ->setParameter('val', $value)
            ->getQuery()
            ->getOneOrNullResult()
        ;
    }
    */
}
