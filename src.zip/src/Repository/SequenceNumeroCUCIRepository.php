<?php

namespace App\Repository;

use App\Entity\SequenceNumeroCUCI;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @method SequenceNumeroCUCI|null find($id, $lockMode = null, $lockVersion = null)
 * @method SequenceNumeroCUCI|null findOneBy(array $criteria, array $orderBy = null)
 * @method SequenceNumeroCUCI[]    findAll()
 * @method SequenceNumeroCUCI[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class SequenceNumeroCUCIRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, SequenceNumeroCUCI::class);
    }

    // /**
    //  * @return SequenceNumeroCUCI[] Returns an array of SequenceNumeroCUCI objects
    //  */
    /*
    public function findByExampleField($value)
    {
        return $this->createQueryBuilder('s')
            ->andWhere('s.exampleField = :val')
            ->setParameter('val', $value)
            ->orderBy('s.id', 'ASC')
            ->setMaxResults(10)
            ->getQuery()
            ->getResult()
        ;
    }
    */

    /*
    public function findOneBySomeField($value): ?SequenceNumeroCUCI
    {
        return $this->createQueryBuilder('s')
            ->andWhere('s.exampleField = :val')
            ->setParameter('val', $value)
            ->getQuery()
            ->getOneOrNullResult()
        ;
    }
    */
}
