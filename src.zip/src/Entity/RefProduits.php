<?php

namespace App\Entity;

use App\Repository\RefProduitsRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=RefProduitsRepository::class)
 */
class RefProduits
{
    /**
     * @ORM\Id
     * @ORM\Column(type="string")
     */
    private $id;

   

    /**
     * @ORM\Column(type="string", length=200, nullable=true)
     */
    private $libelle;

    /**
     * @ORM\ManyToOne(targetEntity=NAEMA::class, inversedBy="refProduits")
     */
    private $naema;

  

    /**
     * @ORM\OneToMany(targetEntity=Ninproduits::class, mappedBy="refproduits")
     */
    private $ninproduits;

    public function __construct()
    {
        $this->ninproduits = new ArrayCollection();
    }

    public function __toString()
    {
        return $this->libelle;
    }


    public function getId(): ?string
    {
        return $this->id;
    }

    public function setId(?string $id): self
    {
        $this->id = $id;

        return $this;
    }


   

    public function getLibelle(): ?string
    {
        return $this->libelle;
    }

    public function setLibelle(?string $libelle): self
    {
        $this->libelle = $libelle;

        return $this;
    }

    public function getNaema(): ?NAEMA
    {
        return $this->naema;
    }

    public function setNaema(?NAEMA $naema): self
    {
        $this->naema = $naema;

        return $this;
    }

   

    /**
     * @return Collection<int, Ninproduits>
     */
    public function getNinproduits(): Collection
    {
        return $this->ninproduits;
    }

    public function addNinproduit(Ninproduits $ninproduit): self
    {
        if (!$this->ninproduits->contains($ninproduit)) {
            $this->ninproduits[] = $ninproduit;
            $ninproduit->setRefproduits($this);
        }

        return $this;
    }

    public function removeNinproduit(Ninproduits $ninproduit): self
    {
        if ($this->ninproduits->removeElement($ninproduit)) {
            // set the owning side to null (unless already changed)
            if ($ninproduit->getRefproduits() === $this) {
                $ninproduit->setRefproduits(null);
            }
        }

        return $this;
    }
}