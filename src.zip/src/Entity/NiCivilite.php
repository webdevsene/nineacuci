<?php

namespace App\Entity;

use App\Repository\NiCiviliteRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=NiCiviliteRepository::class)
 */
class NiCivilite
{
    /**
     * @ORM\Id
     * @ORM\Column(type="string", length=10)

     */
    private $id;

    /**
     * @ORM\Column(type="string",nullable=true, name="nin_Civlibelle")
     */
    private $civlibelle;

  
    


    /**
     * @ORM\OneToMany(targetEntity=NiPersonne::class, mappedBy="civilite")
     */
    private $niPersonnes;

   
 /**
     * @ORM\OneToMany(targetEntity=NiDirigeant::class, mappedBy="ninCivilite")
     */
    private $ninDirigeant;
 

    public function __construct()
    {
        $this->niPersonnes = new ArrayCollection();
        $this->ninDirigeant = new ArrayCollection();
        
    }

    
    public function getId(): ?string
    {
        return $this->id;
    }

    public function getCivcode(): ?string
    {
        return $this->civcode;
    }

    public function setCivcode(?string $civcode): self
    {
        $this->civcode = $civcode;

        return $this;
    }

    public function getCivlibelle(): ?string
    {
        return $this->civlibelle;
    }

    public function setCivlibelle(?string $civlibelle): self
    {
        $this->civlibelle = $civlibelle;

        return $this;
    }

    
    public function __toString()
    {
        return $this->civlibelle;
    }

   
    
    /**
     * @return Collection<int, NiPersonne>
     */
    public function getNiPersonnes(): Collection
    {
        return $this->niPersonnes;
    }

    public function addNiPersonne(NiPersonne $niPersonne): self
    {
        if (!$this->niPersonnes->contains($niPersonne)) {
            $this->niPersonnes[] = $niPersonne;
            $niPersonne->setCivilite($this);
        }

        return $this;
    }

    public function removeNiPersonne(NiPersonne $niPersonne): self
    {
        if ($this->niPersonnes->removeElement($niPersonne)) {
            // set the owning side to null (unless already changed)
            if ($niPersonne->getCivilite() === $this) {
                $niPersonne->setCivilite(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection<int, NiDirigeant>
     */
    public function getNinDirigeant(): Collection
    {
        return $this->ninDirigeant;
    }

    public function addNinDirigeant(NiDirigeant $ninDirigeant): self
    {
        if (!$this->ninDirigeant->contains($ninDirigeant)) {
            $this->ninDirigeant[] = $ninDirigeant;
            $ninDirigeant->setNinCivilite($this);
        }

        return $this;
    }

    public function removeNinDirigeant(NiDirigeant $ninDirigeant): self
    {
        if ($this->ninDirigeant->removeElement($ninDirigeant)) {
            // set the owning side to null (unless already changed)
            if ($ninDirigeant->getNinCivilite() === $this) {
                $ninDirigeant->setNinCivilite(null);
            }
        }

        return $this;
    }

   


}
