<?php

namespace App\Entity;

use App\Repository\NAEMARepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=NAEMARepository::class)
 * @ORM\Table(name="ref_naema")
 */
class NAEMA
{
    /**
     * @ORM\Id
     * @ORM\Column(type="string", length=250, unique=true)
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    private $libelle;

    /**
     * @ORM\OneToMany(targetEntity=Activities::class, mappedBy="nAEMA")
     */
    private $activites;

    /**
     * @ORM\OneToMany(targetEntity=Repertoire::class, mappedBy="naema")
     */
    private $repertoires;

    /**
     * @ORM\OneToMany(targetEntity=NiActivite::class, mappedBy="refNaema")
     */
    private $niActivites;

    /**
     * @ORM\ManyToOne(targetEntity=RefNaemaNew::class, inversedBy="naema")
     */
    private $refNaemaNew;

    /**
     * @ORM\OneToMany(targetEntity=RefProduits::class, mappedBy="naema")
     */
    private $refProduits;

    public function __construct()
    {
        $this->activites = new ArrayCollection();
        $this->repertoires = new ArrayCollection();
        $this->niActivites = new ArrayCollection();
        $this->refProduits = new ArrayCollection();
    }


    public function getCodeLibelle(): ?string
    {
        return $this->id."-".$this->libelle;
    }

    public function __toString()
    {

        return $this->libelle;
        
    }


       /**
     * @return Collection|Repertoires[]
     */
    public function getRepertoire(): Collection
    {
        return $this->repertoires;
    }

    public function addRepertoire(Repertoire $repertoire): self
    {
        if (!$this->repertoires->contains($repertoire)) {
            $this->repertoires[] = $repertoire;
            $repertoire->setNaema($this);
        }

        return $this;
    }

    public function removeRepertoire(Repertoire $repertoire): self
    {
        if ($this->repertoire->removeElement($repertoire)) {
            // set the owning side to null (unless already changed)
            if ($repertoire->getNaema() === $this) {
                $repertoire->setNaema(null);
            }
        }

        return $this;
    }


     public function getNaema(): ?string
    {
        return  $this->id."-".$this->libelle;
    }

    public function getId(): ?string
    {
        return $this->id;
    }

    public function setId(?string $id): self
    {
        $this->id = $id;
        return $this;
    }

    public function getLibelle(): ?string
    {
        return $this->libelle;
    }

    public function setLibelle(?string $libelle): self
    {
        $this->libelle = $libelle;

        return $this;
    }

    /**
     * @return Collection|Activities[]
     */
    public function getActivites(): Collection
    {
        return $this->activites;
    }

    public function addActivite(Activities $activite): self
    {
        if (!$this->activites->contains($activite)) {
            $this->activites[] = $activite;
            $activite->setNAEMA($this);
        }

        return $this;
    }

    public function removeActivite(Activities $activite): self
    {
        if ($this->activites->removeElement($activite)) {
            // set the owning side to null (unless already changed)
            if ($activite->getNAEMA() === $this) {
                $activite->setNAEMA(null);
            }
        }

        return $this;
    }

   

    /**
     * @return Collection|Repertoire[]
     */
    public function getRepertoires(): Collection
    {
        return $this->repertoires;
    }

    /**
     * @return Collection<int, NiActivite>
     */
    public function getNiActivites(): Collection
    {
        return $this->niActivites;
    }

    public function addNiActivite(NiActivite $niActivite): self
    {
        if (!$this->niActivites->contains($niActivite)) {
            $this->niActivites[] = $niActivite;
            $niActivite->setRefNaema($this);
        }

        return $this;
    }

    public function removeNiActivite(NiActivite $niActivite): self
    {
        if ($this->niActivites->removeElement($niActivite)) {
            // set the owning side to null (unless already changed)
            if ($niActivite->getRefNaema() === $this) {
                $niActivite->setRefNaema(null);
            }
        }

        return $this;
    }

    public function getRefNaemaNew(): ?RefNaemaNew
    {
        return $this->refNaemaNew;
    }

    public function setRefNaemaNew(?RefNaemaNew $refNaemaNew): self
    {
        $this->refNaemaNew = $refNaemaNew;

        return $this;
    }

    /**
     * @return Collection<int, RefProduits>
     */
    public function getRefProduits(): Collection
    {
        return $this->refProduits;
    }

    public function addRefProduit(RefProduits $refProduit): self
    {
        if (!$this->refProduits->contains($refProduit)) {
            $this->refProduits[] = $refProduit;
            $refProduit->setNaema($this);
        }

        return $this;
    }

    public function removeRefProduit(RefProduits $refProduit): self
    {
        if ($this->refProduits->removeElement($refProduit)) {
            // set the owning side to null (unless already changed)
            if ($refProduit->getNaema() === $this) {
                $refProduit->setNaema(null);
            }
        }

        return $this;
    }
}
