<?php

namespace App\Entity;

use App\Repository\NiTypevoieRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=NiTypevoieRepository::class)
 */
class NiTypevoie
{
    /**
     * @ORM\Id
     * @ORM\Column(type="string", length=10)

     */
    private $id;

   

    /**
     * @ORM\Column(type="string", length=100, nullable=true, name="nin_Libelle")
     */
    private $tyvlibelle;

    /**
     * @ORM\OneToMany(targetEntity=NiNineaproposition::class, mappedBy="ninType")
     */
    private $niNineapropositions;

    /**
     * @ORM\OneToMany(targetEntity=NINinea::class, mappedBy="ninType")
     */
    private $nINineas;

    /**
     * @ORM\OneToMany(targetEntity=NiCoordonnees::class, mappedBy="ninTypeVoie")
     */
    private $niCoordonnees;


    /**
     * @ORM\OneToMany(targetEntity=NiPersonne::class, mappedBy="ninTypevoie")
     */
    private $niPersonnes;


    public function __construct()
    {
        $this->niNineapropositions = new ArrayCollection();
        $this->nINineas = new ArrayCollection();
        $this->niCoordonnees = new ArrayCollection();
        
        $this->niPersonnes = new ArrayCollection();
    }



    public function getId(): ?string
    {
        return $this->id;
    }

   
    public function getTyvlibelle(): ?string
    {
        return $this->tyvlibelle;
    }

    public function setTyvlibelle(?string $tyvlibelle): self
    {
        $this->tyvlibelle = $tyvlibelle;

        return $this;
    }

    /**
     * @return Collection<int, NiNineaproposition>
     */
    public function getNiNineapropositions(): Collection
    {
        return $this->niNineapropositions;
    }

    public function addNiNineaproposition(NiNineaproposition $niNineaproposition): self
    {
        if (!$this->niNineapropositions->contains($niNineaproposition)) {
            $this->niNineapropositions[] = $niNineaproposition;
            $niNineaproposition->setNinType($this);
        }

        return $this;
    }

    public function removeNiNineaproposition(NiNineaproposition $niNineaproposition): self
    {
        if ($this->niNineapropositions->removeElement($niNineaproposition)) {
            // set the owning side to null (unless already changed)
            if ($niNineaproposition->getNinType() === $this) {
                $niNineaproposition->setNinType(null);
            }
        }

        return $this;
    }


    public function __toString()
    {
        return $this->tyvlibelle;
    }

    /**
     * @return Collection<int, NINinea>
     */
    public function getNINineas(): Collection
    {
        return $this->nINineas;
    }

    public function addNINinea(NINinea $nINinea): self
    {
        if (!$this->nINineas->contains($nINinea)) {
            $this->nINineas[] = $nINinea;
            $nINinea->setNinType($this);
        }

        return $this;
    }

    public function removeNINinea(NINinea $nINinea): self
    {
        if ($this->nINineas->removeElement($nINinea)) {
            // set the owning side to null (unless already changed)
            if ($nINinea->getNinType() === $this) {
                $nINinea->setNinType(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection<int, NiCoordonnees>
     */
    public function getNiCoordonnees(): Collection
    {
        return $this->niCoordonnees;
    }

    public function addNiCoordonnee(NiCoordonnees $niCoordonnee): self
    {
        if (!$this->niCoordonnees->contains($niCoordonnee)) {
            $this->niCoordonnees[] = $niCoordonnee;
            $niCoordonnee->setNinTypeVoie($this);
        }

        return $this;
    }

    public function removeNiCoordonnee(NiCoordonnees $niCoordonnee): self
    {
        if ($this->niCoordonnees->removeElement($niCoordonnee)) {
            // set the owning side to null (unless already changed)
            if ($niCoordonnee->getNinTypeVoie() === $this) {
                $niCoordonnee->setNinTypeVoie(null);
            }
        }

        return $this;
    }

   

    /**
     * @return Collection<int, NiPersonne>
     */
    public function getNiPersonnes(): Collection
    {
        return $this->niPersonnes;
    }

    public function addNiPersonne(NiPersonne $niPersonne): self
    {
        if (!$this->niPersonnes->contains($niPersonne)) {
            $this->niPersonnes[] = $niPersonne;
            $niPersonne->setNinTypevoie($this);
        }

        return $this;
    }

    public function removeNiPersonne(NiPersonne $niPersonne): self
    {
        if ($this->niPersonnes->removeElement($niPersonne)) {
            // set the owning side to null (unless already changed)
            if ($niPersonne->getNinTypevoie() === $this) {
                $niPersonne->setNinTypevoie(null);
            }
        }

        return $this;
    }


}
